/***************************************************************************/
/**
 * @file
 * @brief Efr32 CLI
 *******************************************************************************
 * # License
 * <b>Copyright 2023 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 *
 * https://www.silabs.com/about-us/legal/master-software-license-agreement
 *
 * This software is distributed to you in Source Code format and is governed by
 * the sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#if SL_OPENTHREAD_WORF_CLI_ENABLE

#include <openthread/cli.h>
#include <string.h>
#include "common/code_utils.hpp"
#include "radio_extension.h"
#include "sl_ot_custom_cli.h"

static otError helpCommand(void *context, uint8_t argc, char *argv[]);

//-----------------------------------------------------------------------------
// Wake On RF Get state command
static otError getWorfStateCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);
    OT_UNUSED_VARIABLE(argc);
    OT_UNUSED_VARIABLE(argv);

    otError error = OT_ERROR_NONE;

    uint8_t worfState = 0U;
    SuccessOrExit(error = otPlatRadioExtensionGetWorfState(&worfState));
    otCliOutputFormat("Wake On RF state: %s, %u (us)",
                      (worfState > 0u) ? "ENABLED" : "DISABLED",
                      worfState);
    otCliOutputFormat("\r\n");

exit:
    return error;
}

//------------------------------------------------------------------------------
// Set Wake On RF state from console
// Console Command : "worf set-state <enable>"
// Console Response: none
static otError setWorfStateCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);

    otError error = OT_ERROR_NONE;
    VerifyOrExit(argc == 1, error = OT_ERROR_INVALID_ARGS);

    uint8_t worfState = (uint8_t)strtoul(argv[0], NULL, 10);
    SuccessOrExit(error = otPlatRadioExtensionSetWorfState(worfState));
    otCliOutputFormat("\r\n");

exit:
    return error;
}

//-----------------------------------------------------------------------------
// Get Wake On RF global options and print values to console
// Console Command : "worf get-options"
// Console Response: "Wake On RF Configuration Option: <worfOptions>"
static otError getWorfOptionsCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);
    OT_UNUSED_VARIABLE(argc);
    OT_UNUSED_VARIABLE(argv);

    otError error = OT_ERROR_NONE;
    uint16_t panID;
    uint8_t channel;
    uint8_t optionsMask;

    SuccessOrExit(error = otPlatRadioExtensionGetWorfOptions(&panID, &channel, &optionsMask));

    otCliOutputFormat("Pan ID : 0x%2X, Channel : %u, Options Mask : 0x%X",
                        panID,
                        channel,
                        optionsMask);
    otCliOutputFormat("\r\n");

exit:
    return error;
}

//------------------------------------------------------------------------------
// Set Wake On RF options and (re)enable Wake on RF
// Console Command : "worf set-options"
// Console Response: none
static otError setWorfOptionsCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);

    otError error = OT_ERROR_NONE;
    VerifyOrExit(argc == 3, error = OT_ERROR_INVALID_ARGS);

    uint16_t panID = (uint16_t)strtoul(argv[0], NULL, 10);
    uint8_t channel = (uint8_t)strtoul(argv[1], NULL, 10);
    uint8_t optionsMask = (uint8_t)strtoul(argv[2], NULL, 10);

    SuccessOrExit(error = otPlatRadioExtensionSetWorfOptions(panID, channel, optionsMask));
    otCliOutputFormat("\r\n");

exit:
    return error;
}

//-----------------------------------------------------------------------------
// Get Wake On RF Wake TX options and print values to console
// Console Command : "worf get-tx-options"
// Console Response: "Wake On RF Configuration Option: <worfTxOptions>"
static otError getWorfTxOptionsCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);
    OT_UNUSED_VARIABLE(argc);
    OT_UNUSED_VARIABLE(argv);

    otError error = OT_ERROR_NONE;
    uint8_t txFrameCounter;
    uint8_t ttl;
    uint8_t txOptionsMask;

    SuccessOrExit(error = otPlatRadioExtensionGetWorfWakeTxOptions(&txFrameCounter, &ttl, &txOptionsMask));

    otCliOutputFormat("TX Frame Counter : %u, Time To Live : %u, TX Options Mask : 0x%X",
                        txFrameCounter,
                        ttl,
                        txOptionsMask);
    otCliOutputFormat("\r\n");

exit:
    return error;
}

//------------------------------------------------------------------------------
// Send Wake On RF packet from console
// Console Command : "worf tx"
// Console Response: none
static otError worfTxCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);
    OT_UNUSED_VARIABLE(argc);
    OT_UNUSED_VARIABLE(argv);

    otError error = OT_ERROR_NONE;
    SuccessOrExit(error = otPlatRadioExtensionSetWorfWakeTx());
    otCliOutputFormat("\r\n");

exit:
    return error;
}

//-----------------------------------------------------------------------------

static otCliCommand worfCommands[] = {
    {"help", &helpCommand},
    {"get-state", &getWorfStateCommand},
    {"set-state", &setWorfStateCommand},
    {"get-options", &getWorfOptionsCommand},
    {"set-options", &setWorfOptionsCommand},
    {"get-tx-options", &getWorfTxOptionsCommand},
    {"tx", &worfTxCommand},
};

otError worfCommand(void *context, uint8_t argc, char *argv[])
{
    otError error = processCommand(context, argc, argv, OT_ARRAY_LENGTH(worfCommands), worfCommands);
    
    if (error == OT_ERROR_INVALID_COMMAND)
    {
        (void) helpCommand(NULL, 0, NULL);
    }

    return error;
}

static otError helpCommand(void *context, uint8_t argc, char *argv[])
{
    OT_UNUSED_VARIABLE(context);
    OT_UNUSED_VARIABLE(argc);
    OT_UNUSED_VARIABLE(argv);
    printCommands(worfCommands, OT_ARRAY_LENGTH(worfCommands));

    return OT_ERROR_NONE;
}

#endif // SL_OPENTHREAD_EFR32_CLI_ENABLE
